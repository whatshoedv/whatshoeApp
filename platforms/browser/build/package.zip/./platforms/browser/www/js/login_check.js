/**
 * Created by byeongkwan on 2017-02-09.
 */
$('#login_btn').click(function () {
   var login_id = document.getElementById('login_id');
   var login_pw = document.getElementById('login_pw');

   if(!valid_Idcheck(login_id)){

   } else if(!valid_PwCheck(login_pw,login_pw)){

   } else {

   }
});