/**
 * Created by byeongkwan on 2017-02-08.
 */
function Client(Id, Name, Pw, Pw_more, Gender, Birth, Email, Phone){
    this.Id = Id;
    this.Name = Name;
    this.Pw = Pw;
    this.Pw_more = Pw_more;
    this.Gender = Gender;
    this.Birth = Birth;
    this.Email = Email;
    this.phone = Phone;
}
