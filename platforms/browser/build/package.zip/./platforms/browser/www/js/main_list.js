/**
 * Created by byeongkwan on 2017-02-15.
 */
$('#list_head_back').click(function () {
   location.href="main.html";
});